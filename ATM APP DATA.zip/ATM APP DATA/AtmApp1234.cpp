//Implementation file for ATM APP.
//#Program Name:ATMApp11234.cpp
//#Author: Sukhkaran Gill.
//#Date Last Updated: 07/30/2022
//#Purpose: To define implementation file .cpp to run the APP for ATM machine.
//Include header file BankDatabase1234.h
#include "BankDatabase1234.h"
#include<iostream>
#include<cstdlib>
#include<string>
using namespace std;
int main()
{
    BankDatabase demo;//Create BankDatabase Object.
    demo.appendNode(1234567890);
    demo.appendNode(1468965461);
    demo.authenticateUser();//Call function authenticate User for ATM APP functionality.
    return 0;
}