//Specification file for the Display1 Header file Program.
//#Program Name:Display1234.h
//#Author: Sukhkaran Gill.
//#Date Last Updated: 07/30/2022
//#Purpose: To define header file that will display ATM menu and ask for choice for menu options.
#ifndef Display_H
#define Display_H
#include<iostream>
#include<string>
class Display
{
    private:
    int ch;
    public:
    Display( )
    {
      ch=0;
    }
    int displayMainMenu()//Function for Main menu.
    {
	    std::cout<<"Main Menu"<<std::endl;
	    std::cout<<"1-View Balance"<<std::endl;
	    std::cout<<"2-Withdraw cash"<<std::endl;
	   std::cout<<"3-Deposit cash"<<std::endl;
	   std::cout<<"4-Exit\n"<<std::endl;
	   std::cout<<"Enter a choice"<<std::endl;
     std::cin>>ch;
     return ch;
}
};
#endif