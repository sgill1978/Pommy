//Specification file for the BankDatabase1 Header file Program.
//#Program Name:BankDatabase11234.h
//#Author: Sukhkaran Gill.
//#Date Last Updated: 07/30/2022
//#Purpose: To define header class and functions to perform transaction , authenticate user and Validate PIN.
#ifndef BANKDATABASE_H
#define BANKDATABASE_H
#include<iostream>
#include<string>
#include <stddef.h>
#include "Display1234.h"//Include Display1234.h header file.
class BankDatabase//Class BankDatabase  extends Class ATM.
{
private:
struct ListNode
 {
    int value;
    struct ListNode *next;
 };
ListNode *head;
int userAccountNumber;//Variable used to handle Debit card or credit card number of the customer.
int userPin;//Variable for user pin code for the account
static const  int BANK_USER=2;//Constant for array number of rows.
static const  int BANK_DATA=3;//Constant for array number of columns.
int bank[BANK_USER][BANK_DATA]={{1234,500,15000},{1456,400,16000}};
 //long long int userPin;
 float amount;
 public: 
BankDatabase ()//Constructor for the class, intializes the two variables.
{
 userAccountNumber=0;
 userPin=0;
 head=nullptr;
}
//~BankDatabase();
 void appendNode(int acc)
 {
    ListNode *newAcc; //To point to a new node
    ListNode *nodePtr; //To move through the list
    //Allocate a new node and store account number.
    newAcc=new ListNode;
    newAcc->value=acc;
    newAcc->next=nullptr;
    //if there are no nodes in the list
    //make newAcc the first node
    if (!head)
    {
    head=newAcc;
    }
    else//otherwise insert newAcc at end
    {
        //intialize nodeptr to head of list
        nodePtr=head;
        //Find the last node in the list
        while (nodePtr->next)
        nodePtr=nodePtr->next;
        //Insert newAcc as the last node.
        nodePtr->next=newAcc;
    }
 }
 int withdrawl(int acc,int pin,int amt )//Function for withdrawl transaction.
{
    int temp;
    int choice;
    ListNode *nodePtr,*node1;
    nodePtr=head;
    node1=nodePtr->next;
    temp=node1->value;
    std::cout<<"Enter 1 for Checkings:"<<std::endl;
    std::cout<<"Enter 2 for Savings:"<<std::endl;
    std::cin>>choice;
    switch (choice)
    {
    case 1:
          if (acc==nodePtr->value&&pin==bank[0][0])
      {
          try//try and catch block for overdraft amount.
        {
           if (amt>bank[0][1])
           {
            throw std::invalid_argument("Amount is invalid");
           }
        }
        catch(std::invalid_argument)
        {
            std::cout<<"An overdraft fees of $5 will be charged. It will be deducted from the Checking account"<<std::endl;
            temp=bank[0][1]-(amt+5);
            bank[0][1]=temp;//Update the savings account to new amount after withdrawl.
           return temp; 
        }
          temp=bank[0][1]-amt;
          bank[0][1]=temp;//Update the savings account to new amount after withdrawl.
          return temp;      
      }
      if (acc==temp&&pin==bank[1][0])
      {
        try//try and catch block for overdraft amount.
        {
           if (amt>bank[1][1])
           {
            throw std::invalid_argument("Amount is invalid");
           }
        }
        catch(std::invalid_argument)
        {
            std::cout<<"An overdraft fees of $5 will be charged. It will be deducted from the Checking account"<<std::endl;
            temp=bank[1][1]-(amt+5);
            bank[1][1]=temp;//Update the savings account to new amount after withdrawl.
           return temp; 
        }
       temp=bank[1][1]-amt; 
       bank[1][1]=temp;//Update the savings account to new amount after withdrawl.
       return temp;
      }
      break;
    
    case 2:
             if (acc==temp&&pin==bank[1][0])
      {
          temp=bank[1][2]-amt;
          bank[1][2]=temp;//Update the checking account to new amount after withdrawl.
         return temp;
      }
      if (acc==nodePtr->value&&pin==bank[0][0])
      {
        temp=bank[0][2]-amt;
        bank[0][2]=temp;//Update the checking account to new amount after withdrawl.
        return temp;
      }
    default:
        exit;
    }
}
int deposit(int acc,int pin,int amt)//Function for deposit transaction.
{
    int temp;
    int choice;
    ListNode *nodePtr,*node1;
    nodePtr=head;
    node1=nodePtr->next;
    temp=node1->value;
    std::cout<<"Enter 1 for Checkings:"<<std::endl;
    std::cout<<"Enter 2 for Savings:"<<std::endl;
    std::cin>>choice;
    switch (choice)
    {
    case 1:
        if (acc==nodePtr->value&&pin==bank[0][0])
      {
          temp=bank[0][1]+amt;
          bank[0][1]=temp;//Update the savings account after depositing amount.
          return temp;
      }
      if (acc==temp&&pin==bank[1][0])
      {
       temp=bank[1][1]+amt;
       bank[1][1]=temp;//Update the savings account after depositing amount.  
       return temp;
      }
        break;
    case 2:
          if (acc==temp&&pin==bank[1][0])
      {
          temp=bank[1][2]+amt;
          bank[1][2]=temp;//Update the checkings account after deposit.
          return temp;
      }
      if (acc==nodePtr->value&&pin==bank[0][0])
      {
        temp=bank[0][2]+amt;
        bank[0][2]=temp;//Update the checkings account after deposit.
        return temp;
      }
      
    default:
        exit;
    }  
} 
void balanceInquiry(int acc,int pin)//Function for balance inquiry.
{
    int ch;
    int temp;
    ListNode *nodePtr,*node1;
    nodePtr=head;
    node1=nodePtr->next;
    temp=node1->value;
   do
    {
    if (acc==nodePtr->value&&pin==bank[0][0])
     {
    std::cout<<"The current  balance on Checking Account is :"<<bank[0][1]<<std::endl;
    std::cout<<"The current balance on Savings Account is : "<<bank[0][2]<<std::endl;
     }
     else if (acc==temp&&pin==bank[1][0])
     {
    std::cout<<"The current  balance on Checking Account is :"<<bank[1][1]<<std::endl;
    std::cout<<"The current balanve on Savings Account is : "<<bank[1][2]<<std::endl;
     }
else
{
    try//try and catch block to validate Debit/credit card account number.
    {
      throw std::invalid_argument("Invalid data");
    }
    catch(std::invalid_argument)
    {
    std::cout<<"Swipe Card again or Enter Account Information"<<std::endl;
    }
    std::cout<<"Try again. Press Y to continue or Press N to exit: "<<std::endl;
    std::cin>>ch;
}
 }while (ch=='Y');
}
bool validatePIN(int uAccountNumber,int uPIN)//Function to validate pin based on user account number.
{
 int temp;
 ListNode *nodePtr, *node1;
 nodePtr=head;
 node1=nodePtr->next;
 temp=node1->value;
 while (nodePtr)
 {
 if (uAccountNumber==nodePtr->value&&uPIN==bank[0][0]||uAccountNumber==temp&&uPIN==bank[1][0])
 {
    std::cout<<"Valid PIN, please continue with the trasaction"<<std::endl;;
    return true;
 }
 nodePtr=nodePtr->next;
 }
 std::cout<<"Invalid PIN, please try again: "<<std::endl;
 return false;
}


void performTransaction()//Function to perform ATM transactions.
{
	int choice;
    float with;
    float dep;
     float w;
    float d;
    bool userExited=false;
    //loop untill user has not chosen to exit
	while(!userExited) {
        Display dem2;
        choice=dem2.displayMainMenu();
		switch(choice)
		{
		case 1:
		balanceInquiry(userAccountNumber,userPin);//Call function to account current balance.
        break;
		case 2:
        std::cout<<"Enter withdrawl amount: "<<std::endl;
        std::cin>>with;
        do
        {
        try//Try and Catch block to validate withdrawl amount is less than 200 dollars.
        {
           if (with>200)
           {
            throw std::invalid_argument("The Withdrawl amount must be less than 200 dollars");
           }
        }
        catch(std::invalid_argument)
        {
            std::cout<<"Please enter the amount again should not exceed 200 dollars"<<std::endl;
            std::cin>>with;
        }
        }while(with>200);
        w=withdrawl(userAccountNumber,userPin,with);//Call withdrawl function to perform withdrawl transaction.
        std::cout<<"The amount after withdrawl is :"<<w<<std::endl;
        break;
		case 3:
        std::cout<<"Enter deposit amount: "<<std::endl;
        std::cin>>dep;
        do
        {
        try//Try and catch block to validate of deposit amount is greater than 0.
        {
           if (dep<=0)
           {
            throw std::invalid_argument("The Deposit amount is invalid");
           }
        }
        catch(std::invalid_argument)
        {
            std::cout<<"Please enter the amount again.The deposit amount should be greater than zero"<<std::endl;
            std::cin>>dep;
        }
        }while(dep<=0);
		d=deposit(userAccountNumber,userPin,dep);//Call deposit function to perform deposit transaction.
        std::cout<<"The amount after deposit is :"<<d<<std::endl;
        break;
		case 4:
	    std::cout<<"Exiting the ATM"<<std::endl;
	    userExited=true;
        break;
	    default:
	    std::cout<<"Valid Selection not entered, Try again"<<std::endl;
	    }
	}
}

void authenticateUser() //Function used to autheticate user and perform then perform transactions.
     {
    int accountNumber;//Variable to Debit or credit card number
    int pin;//Variable to pin number.
    bool userAuthenticated=false;//Boolean varaible to hold true or false value when user is authenticated. 
    std::cout<<"Enter the Debit card or Credit Card Number: "<<std::endl;//Message to enter debit card or credit card number
    std::cin>>accountNumber;//Enter the credit card or debit card number.
    userAccountNumber=accountNumber;
	std::cout<<"Enter the pin number: "<<std::endl;//Message to enter the pin number.
    std::cin>>pin;//Enter the pin number.
    userPin=pin;
	userAuthenticated=authenticateUserid(userAccountNumber,userPin);//Authenticate user.
	if(userAuthenticated)
	{
	  performTransaction();//If user is authenticated perform the transactions.
	}
	else 
	{
		std::cout<<"Invalid account number or PIN. Please try again";
	}
}
bool authenticateUserid(int userAccountNumber,int userPIN)//Function to authenticate user .
{
    int temp;
    bool result;
    ListNode *nodePtr;
    nodePtr=head;
    while (nodePtr)
    {
    if (userAccountNumber!=0&&userAccountNumber==nodePtr->value)
    {
      temp=nodePtr->value;
	  result=validatePIN(userAccountNumber,userPIN);//Fucntion to validate pin.\
    }
    nodePtr=nodePtr->next;
    }
    if (result==true)
    {
     return true;   
    }
    else
    {
     return false;
    }
}}
};
#endif